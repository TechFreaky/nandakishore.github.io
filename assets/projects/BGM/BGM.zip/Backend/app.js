//require express for creating api's
var express = require('express')
//create a reference variable for express()
var app = express()

//require opn
var open = require('opn')



//create an api to get the bgm links
app.get('/getlink', function(req, res){

	var link = req.query.link
	var nameOfBGM = req.query.nameOfBGM
	console.log("Playing '"+nameOfBGM+"'")
	open(link)
	res.send("Success");

})


//create a port to listen
app.listen('2500')

console.log('Listening at port 2500')